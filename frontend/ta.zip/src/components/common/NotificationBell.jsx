import React, { useState } from 'react';
import { useNotifications } from '../context/NotificationContext';

const NotificationBell = () => {
  const [open, setOpen] = useState(false);

  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead
  } = useNotifications();

  const handleNotificationClick = async (notification) => {
    if (!notification.isRead) {
      await markAsRead(notification._id);
    }
  };

  return (
    <div
      style={{
        position: 'relative'
      }}
    >
      {/* Bell Button */}
      <button
        type="button"
        onClick={() => setOpen(!open)}
        style={{
          position: 'relative',
          border: 'none',
          background: 'transparent',
          cursor: 'pointer',
          fontSize: '24px',
          padding: '8px'
        }}
      >
        🔔

        {unreadCount > 0 && (
          <span
            style={{
              position: 'absolute',
              top: '0px',
              right: '0px',
              background: 'red',
              color: 'white',
              borderRadius: '50%',
              minWidth: '18px',
              height: '18px',
              fontSize: '11px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '2px'
            }}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Notification Dropdown */}
      {open && (
        <div
          style={{
            position: 'absolute',
            right: 0,
            top: '45px',
            width: '350px',
            maxHeight: '450px',
            overflowY: 'auto',
            background: '#ffffff',
            border: '1px solid #ddd',
            borderRadius: '8px',
            boxShadow: '0 5px 20px rgba(0,0,0,0.15)',
            zIndex: 9999
          }}
        >
          {/* Header */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '15px',
              borderBottom: '1px solid #eee'
            }}
          >
            <strong>Notifications</strong>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={markAllAsRead}
                style={{
                  border: 'none',
                  background: 'transparent',
                  cursor: 'pointer',
                  color: '#007bff',
                  fontSize: '13px'
                }}
              >
                Mark all as read
              </button>
            )}
          </div>

          {/* Notification List */}
          {notifications.length === 0 ? (
            <div
              style={{
                padding: '30px',
                textAlign: 'center',
                color: '#777'
              }}
            >
              No notifications
            </div>
          ) : (
            notifications.map((notification) => (
              <div
                key={notification._id}
                onClick={() =>
                  handleNotificationClick(notification)
                }
                style={{
                  padding: '14px 15px',
                  borderBottom: '1px solid #eee',
                  cursor: 'pointer',
                  background: notification.isRead
                    ? '#ffffff'
                    : '#f0f7ff'
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    gap: '8px'
                  }}
                >
                  {!notification.isRead && (
                    <span
                      style={{
                        color: '#007bff'
                      }}
                    >
                      ●
                    </span>
                  )}

                  <div>
                    <strong
                      style={{
                        display: 'block',
                        marginBottom: '5px'
                      }}
                    >
                      {notification.title}
                    </strong>

                    <div
                      style={{
                        fontSize: '14px',
                        color: '#555'
                      }}
                    >
                      {notification.message}
                    </div>

                    <div
                      style={{
                        fontSize: '12px',
                        color: '#999',
                        marginTop: '7px'
                      }}
                    >
                      {new Date(
                        notification.createdAt
                      ).toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationBell;